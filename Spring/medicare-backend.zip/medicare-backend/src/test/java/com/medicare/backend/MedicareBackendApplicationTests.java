package com.medicare.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicareBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
